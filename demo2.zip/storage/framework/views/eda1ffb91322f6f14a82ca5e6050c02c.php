<!-- resources/views/resolved-tickets.blade.php -->

 <!-- Assuming you have a master layout file -->

<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Resolved Tickets</h1>

        <?php if(count($resolvedTickets) > 0): ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Description</th>
                        <!-- Add more columns if needed -->
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $resolvedTickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($ticket->title); ?></td>
                            <td><?php echo e($ticket->description); ?></td>
                            <!-- Add more columns if needed -->
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No resolved tickets found.</p>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ucc/demo-app/resources/views/resolved-tickets.blade.php ENDPATH**/ ?>